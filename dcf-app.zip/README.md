# Hello World TypeScript Project

A simple Hello World project built with TypeScript.

## Project Structure

- `src/` - TypeScript source files
- `dist/` - Compiled JavaScript output
- `tsconfig.json` - TypeScript configuration

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Build the project:
   ```bash
   npm run build
   ```

3. Run the compiled code:
   ```bash
   npm start
   ```

4. Or run directly with ts-node (development):
   ```bash
   npm run dev
   ```

## Features

- TypeScript strict mode enabled
- Source maps for debugging
- ESM and CommonJS support configured
- Type definitions included

## License

MIT
