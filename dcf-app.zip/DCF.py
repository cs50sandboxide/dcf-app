import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# defining a function to obtain data for stocks based on ticker

stock = input("Enter stock ticker symbol (e.g., AAPL, MSFT, AMZN, GOOGL, NVDA, META, TSLA, JPM, V, UNH): ")

def read_stockdata(stock_name):

    data = pd.read_csv('Data.csv', thousands=',')

    Revenue_name = stock_name+'_Revenue'
    EBIT_name = stock_name+'_EBIT'
    DA_name = stock_name+'_DA'
    CapEx_name = stock_name+'_CapEx'
    Assets_name = stock_name+'_Assets'
    Liabilities_name = stock_name+'_Liabilities'
    Cash_name = stock_name+'_Cash'
    Debt_name = stock_name+'_Debt'
    Shares_name = stock_name+'_Shares'

    Reported_Revenue = data[Revenue_name]
    Reported_EBIT = data[EBIT_name]
    Reported_DA = data[DA_name]
    Reported_CapEx = data[CapEx_name]
    Reported_Assets = data[Assets_name]
    Reported_Liabilities = data[Liabilities_name]
    Reported_Cash = data[Cash_name]
    Reported_Debt = data[Debt_name]
    Reported_Shares = data[Shares_name]

    return (Reported_Revenue, Reported_EBIT, Reported_DA, Reported_CapEx,
            Reported_Assets, Reported_Liabilities, Reported_Cash, Reported_Debt,
            Reported_Shares)

stock_data = read_stockdata(stock)

# we now have the needed data for each stock, and can proceed to calculate free cash flows

Revenue = stock_data[0]
EBIT = stock_data[1]
DA = stock_data[2]
CapEx = stock_data[3]
Assets = stock_data[4]
Liabilities = stock_data[5]
Cash = stock_data[6]
Debt = stock_data[7]
Shares = stock_data[8]

# since projection requires an average growth rate, we can create a general function to calculate growth, which can then be called for revenue, ebit, etc

def calculate_growth(data_series):
    growth_rates = []
    i = 0
    while i < len(data_series) - 1 and pd.notna(data_series[i+1]): 
        growth = (data_series[i+1] - data_series[i]) / data_series[i]
        growth_rates.append(growth)
        i = i + 1
    average_growth = sum(growth_rates) / len(growth_rates)
    return average_growth*100

#print(calculate_growth(Revenue))

# we also need functions to estimate average ebit, etc percent, which is then used to project future values 

def calculate_percentage(data_series, base_series):
    percentages = []
    i = 0
    while i < len(data_series) and pd.notna(data_series[i]) and pd.notna(base_series[i]):
        percentage = data_series[i] / base_series[i]
        percentages.append(percentage)
        i = i + 1
    average_percentage = sum(percentages) / len(percentages)
    return average_percentage*100

#print(calculate_percentage(EBIT, Revenue))
#print(calculate_percentage(DA, Revenue))
#print(calculate_percentage(CapEx, Revenue))

def projecting_values(last_value, growth_rate, years):
    projections = []
    for year in range(1, years + 1):
        projected_value = last_value * ((1 + growth_rate) ** year)
        projections.append(projected_value)
    return projections

stock_revenue_projections = projecting_values(Revenue.dropna().values[-1], calculate_growth(Revenue)/100, 5)
#print(stock_revenue_projections)
stock_ebit_projections = projecting_values(EBIT.dropna().values[-1], calculate_growth(EBIT)/100, 5)
stock_da_projections = projecting_values(DA.dropna().values[-1], calculate_growth(DA)/100, 5)
stock_capex_projections = projecting_values(CapEx.dropna().values[-1], calculate_growth(CapEx)/100, 5)

# now we just need NOPAT projections, where an effective tax rate must be assumed, and a NWC projection 

Tax_Rate = 0.27

def calculate_nopat(ebit, tax_rate):
    nopat = ebit * (1 - tax_rate)
    return nopat

NOPAT = [calculate_nopat(ebit, Tax_Rate) for ebit in EBIT.dropna().values]
NOPAT_projections = [calculate_nopat(ebit, Tax_Rate) for ebit in stock_ebit_projections]

#print(NOPAT)
#print(NOPAT_projections)

def calculate_nwc(assets, liabilities, cash, debt):
    nwc = assets - liabilities - cash + debt
    return nwc

Avg_NWC_Percent = calculate_percentage(calculate_nwc(Assets, Liabilities, Cash, Debt), Revenue)
#print(Avg_NWC_Percent)

NWC_Projections = []
for i in range(5):
    NWC_Projections.append(stock_revenue_projections[i] * (Avg_NWC_Percent / 100))

#print(NWC_Projections)

# since we need chnage in NWC

Change_in_NWC = []

Change_in_NWC.append(NWC_Projections[0] - calculate_nwc(Assets.dropna().values[-1], Liabilities.dropna().values[-1], Cash.dropna().values[-1], Debt.dropna().values[-1]))

for i in range (1,5):
    Change_in_NWC.append(NWC_Projections[i] - NWC_Projections[i-1])


#print(Change_in_NWC)

# now we can calculate FCFF projections, which is given by FCFF = EBIT*(1-Tax Rate) + DA - CapEx - Change in NWC

FCFF_Projections = []

for i in range(5):
    fcff = NOPAT_projections[i] + stock_da_projections[i] - stock_capex_projections[i] - Change_in_NWC[i]
    FCFF_Projections.append(fcff)

#print(FCFF_Projections)

# now we have to discount the FCFF projections to present value, using the WACC

# ideally we would have a function to calculate WACC, but instead were assuming it to be 6.9%

WACC = 0.069

PV_FCFF = []
for i in range(5):
    pv_fcff = FCFF_Projections[i] / ((1 + WACC) ** (i + 1))
    PV_FCFF.append(pv_fcff)

#print(PV_FCFF)

# we now also have to calculate the terminal value beyond the 5 year projection period, which is done as:

FCFF_year_after_5 = FCFF_Projections[4] * (1 + 0.025)  # assuming a perpetual growth rate of 2.5%
Terminal_Value = FCFF_year_after_5 / (WACC - 0.025)
PV_Terminal_Value = Terminal_Value / ((1 + WACC) ** 5)

#print(PV_Terminal_Value)

Enterprise_Value = sum(PV_FCFF) + PV_Terminal_Value
#print(Enterprise_Value)

Equity_Value = Enterprise_Value - Debt.dropna().values[-1] + Cash.dropna().values[-1]

Intrinsic_Value = Equity_Value / Shares.dropna().values[-1]

print(f"The intrinsic value per share of {stock} is: ${Intrinsic_Value:.2f}")









