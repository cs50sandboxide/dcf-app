function greet(name: string): void {
  console.log(`Hello, ${name}! Welcome to TypeScript.`);
}

const message: string = "World";
greet(message);
