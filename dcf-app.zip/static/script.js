let revenueChart = null;
let fcffChart = null;

document.addEventListener('DOMContentLoaded', function() {
    loadAvailableStocks();
    
    document.getElementById('calculate-btn').addEventListener('click', calculateValuation);
    document.getElementById('stock-select').addEventListener('change', clearResults);
});

function loadAvailableStocks() {
    fetch('/api/stocks')
        .then(response => response.json())
        .then(stocks => {
            const select = document.getElementById('stock-select');
            select.innerHTML = '<option value="">Select a stock...</option>';
            stocks.forEach(stock => {
                const option = document.createElement('option');
                option.value = stock;
                option.textContent = stock;
                select.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error loading stocks:', error);
            showError('Failed to load available stocks');
        });
}

function clearResults() {
    document.getElementById('results-panel').style.display = 'none';
    document.getElementById('charts-section').style.display = 'none';
}

function calculateValuation() {
    const stock = document.getElementById('stock-select').value;
    const taxRate = parseFloat(document.getElementById('tax-rate').value);
    const wacc = parseFloat(document.getElementById('wacc').value);
    const terminalGrowth = parseFloat(document.getElementById('terminal-growth').value);

    if (!stock) {
        showError('Please select a stock');
        return;
    }

    // Validate inputs
    if (isNaN(taxRate) || isNaN(wacc) || isNaN(terminalGrowth)) {
        showError('Please enter valid numbers for all parameters');
        return;
    }

    document.getElementById('loading').style.display = 'block';
    document.getElementById('error-message').classList.remove('show');

    fetch('/api/calculate', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            stock: stock,
            tax_rate: taxRate,
            wacc: wacc,
            terminal_growth: terminalGrowth
        })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('loading').style.display = 'none';
        
        if (data.error) {
            showError(data.error);
        } else {
            displayResults(data);
        }
    })
    .catch(error => {
        document.getElementById('loading').style.display = 'none';
        console.error('Error:', error);
        showError('Failed to calculate valuation: ' + error.message);
    });
}

function displayResults(data) {
    // Display main results
    document.getElementById('intrinsic-value').textContent = 
        '$' + data.intrinsic_value.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    
    document.getElementById('enterprise-value').textContent = 
        '$' + (data.enterprise_value / 1e9).toFixed(2) + 'B';
    
    document.getElementById('equity-value').textContent = 
        '$' + (data.equity_value / 1e9).toFixed(2) + 'B';
    
    document.getElementById('pv-terminal').textContent = 
        '$' + (data.pv_terminal_value / 1e9).toFixed(2) + 'B';

    // Display assumptions
    const assumptionsDiv = document.getElementById('assumptions-display');
    assumptionsDiv.innerHTML = `
        <div class="stat-row">
            <span class="stat-label">Tax Rate</span>
            <span class="stat-value">${data.assumptions.tax_rate.toFixed(1)}%</span>
        </div>
        <div class="stat-row">
            <span class="stat-label">WACC</span>
            <span class="stat-value">${data.assumptions.wacc.toFixed(1)}%</span>
        </div>
        <div class="stat-row">
            <span class="stat-label">Terminal Growth Rate</span>
            <span class="stat-value">${data.assumptions.terminal_growth.toFixed(1)}%</span>
        </div>
    `;

    // Display growth rates
    const growthDiv = document.getElementById('growth-rates-display');
    growthDiv.innerHTML = `
        <div class="stat-row">
            <span class="stat-label">Revenue Growth</span>
            <span class="stat-value">${data.growth_rates.revenue.toFixed(2)}%</span>
        </div>
        <div class="stat-row">
            <span class="stat-label">EBIT Growth</span>
            <span class="stat-value">${data.growth_rates.ebit.toFixed(2)}%</span>
        </div>
        <div class="stat-row">
            <span class="stat-label">D&A Growth</span>
            <span class="stat-value">${data.growth_rates.da.toFixed(2)}%</span>
        </div>
        <div class="stat-row">
            <span class="stat-label">CapEx Growth</span>
            <span class="stat-value">${data.growth_rates.capex.toFixed(2)}%</span>
        </div>
    `;

    // Show results panel
    document.getElementById('results-panel').style.display = 'block';

    // Create charts
    createCharts(data);

    // Show charts section
    document.getElementById('charts-section').style.display = 'grid';

    // Scroll to results
    setTimeout(() => {
        document.getElementById('results-panel').scrollIntoView({ behavior: 'smooth' });
    }, 100);
}

function createCharts(data) {
    const years = ['Year 1', 'Year 2', 'Year 3', 'Year 4', 'Year 5'];

    // Revenue Chart
    const revenueCtx = document.getElementById('revenue-chart').getContext('2d');
    
    if (revenueChart) {
        revenueChart.destroy();
    }

    revenueChart = new Chart(revenueCtx, {
        type: 'bar',
        data: {
            labels: years,
            datasets: [{
                label: 'Projected Revenue ($M)',
                data: data.revenue_projections.map(r => r / 1e6),
                backgroundColor: 'rgba(37, 99, 235, 0.8)',
                borderColor: 'rgba(37, 99, 235, 1)',
                borderWidth: 2,
                borderRadius: 6,
                hoverBackgroundColor: 'rgba(37, 99, 235, 0.9)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: true,
                    labels: {
                        font: { size: 12, weight: '500' }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });

    // FCFF Chart
    const fcffCtx = document.getElementById('fcff-chart').getContext('2d');
    
    if (fcffChart) {
        fcffChart.destroy();
    }

    fcffChart = new Chart(fcffCtx, {
        type: 'line',
        data: {
            labels: years,
            datasets: [{
                label: 'Free Cash Flow to Firm ($M)',
                data: data.fcff_projections.map(f => f / 1e6),
                borderColor: 'rgba(16, 185, 129, 1)',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                borderWidth: 3,
                pointBackgroundColor: 'rgba(16, 185, 129, 1)',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 6,
                pointHoverRadius: 8,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: true,
                    labels: {
                        font: { size: 12, weight: '500' }
                    }
                }
            },
            scales: {
                y: {
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });
}

function showError(message) {
    const errorDiv = document.getElementById('error-message');
    errorDiv.textContent = message;
    errorDiv.classList.add('show');
}
