# DCF Stock Valuation Website

An interactive web application for calculating intrinsic stock valuations using Discounted Cash Flow (DCF) analysis.

## Features

- 📊 Interactive DCF valuation calculator
- 📈 Real-time projection charts
- ⚙️ Customizable assumptions (Tax Rate, WACC, Terminal Growth)
- 💻 Modern, responsive web interface
- 🎯 Support for multiple stocks

## Prerequisites

- Python 3.8+
- pip (Python package manager)

## Installation & Setup

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the Flask Server

```bash
python app.py
```

The application will be available at `http://localhost:5000`

## Usage

1. **Select a Stock** - Choose from available stock tickers in the dropdown
2. **Set Parameters**:
   - Tax Rate (default: 27%)
   - WACC (default: 6.9%)
   - Terminal Growth Rate (default: 2.5%)
3. **Click "Calculate Valuation"** - View results instantly
4. **Review Results**:
   - Intrinsic value per share
   - Enterprise and equity values
   - Historical growth rates
   - 5-year projections with charts

## File Structure

```
.
├── app.py                 # Flask backend server
├── Data.csv              # Stock financial data
├── requirements.txt      # Python dependencies
├── templates/
│   └── index.html       # Main web interface
├── static/
│   ├── style.css        # Styling
│   └── script.js        # Frontend logic
└── README.md
```

## Available Stocks

The calculator supports stocks with data in `Data.csv`:
- AAPL, MSFT, AMZN, GOOGL, NVDA, META, TSLA, JPM, V, UNH (and more)

## DCF Calculation Process

The valuation follows these steps:

1. **Data Loading** - Retrieve historical financial metrics
2. **Growth Analysis** - Calculate average historical growth rates
3. **Projections** - Project 5 years of revenue, EBIT, D&A, and CapEx
4. **FCFF Calculation** - Compute Free Cash Flow to Firm
5. **Discounting** - Discount cash flows using WACC
6. **Terminal Value** - Calculate perpetuity value
7. **Valuation** - Derive intrinsic value per share

## Assumptions

- **Default Tax Rate**: 27%
- **Default WACC**: 6.9%
- **Default Terminal Growth**: 2.5%
- **Projection Period**: 5 years

## API Endpoints

- `GET /` - Main page
- `GET /api/stocks` - List available stock tickers
- `POST /api/calculate` - Calculate DCF valuation

### POST /api/calculate Request Body

```json
{
  "stock": "AAPL",
  "tax_rate": 27,
  "wacc": 6.9,
  "terminal_growth": 2.5
}
```

## License

MIT

## Author

Created for interactive DCF stock analysis
