# Deploy to Wix - Setup Guide

## Option A: Deploy to Render (Recommended - Free Tier)

1. **Create Render account** at [https://render.com](https://render.com)
2. **Connect GitHub**:
   - Push your code to GitHub (including the Procfile and requirements.txt)
   - Login to Render → Dashboard → New → Web Service
3. **Configure**:
   - Repository: Select your repo
   - Environment: Python
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `gunicorn app:app`
4. **Deploy** - Render will give you a URL like `https://your-app.onrender.com`

## Option B: Deploy to Railway

1. Visit [https://railway.app](https://railway.app)
2. Connect GitHub account
3. Create new project → Deploy from GitHub
4. Select your repo
5. It auto-detects Procfile and requirements.txt
6. Get your API URL

## Option C: Deploy to Heroku (Requires Credit Card)

1. Install Heroku CLI: `brew install heroku`
2. `heroku login`
3. `heroku create your-app-name`
4. `git push heroku main`

---

## Using in Wix

Once deployed, you'll have a URL like: `https://your-app.onrender.com`

### Add to Wix:

1. **Add Custom Embed Element** in Wix Editor
2. **Call your API from Wix Velo** (in Custom Code):

```javascript
// In Wix Velo Code
import { fetch } from 'wix-fetch';

async function calculateDCF(stock, taxRate, wacc, terminalGrowth) {
  const response = await fetch('https://your-app.onrender.com/api/calculate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      stock: stock,
      tax_rate: taxRate,
      wacc: wacc,
      terminal_growth: terminalGrowth
    })
  });
  return response.json();
}

// Get available stocks
async function getStocks() {
  const response = await fetch('https://your-app.onrender.com/api/stocks');
  return response.json();
}
```

3. **Or embed HTML directly** in Wix using this in a Custom Element:

```html
<form id="dcfForm">
  <select id="stock"></select>
  <input type="number" id="taxRate" value="27">
  <input type="number" id="wacc" value="6.9">
  <button type="submit">Calculate</button>
</form>

<script>
  const API_URL = 'https://your-app.onrender.com';
  
  // Load stocks
  fetch(`${API_URL}/api/stocks`)
    .then(r => r.json())
    .then(stocks => {
      const select = document.getElementById('stock');
      stocks.forEach(s => {
        const option = document.createElement('option');
        option.value = s;
        option.text = s;
        select.add(option);
      });
    });
  
  // Handle form submission
  document.getElementById('dcfForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const result = await fetch(`${API_URL}/api/calculate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        stock: document.getElementById('stock').value,
        tax_rate: parseInt(document.getElementById('taxRate').value),
        wacc: parseInt(document.getElementById('wacc').value),
        terminal_growth: 2.5
      })
    }).then(r => r.json());
    
    console.log(result);
    // Display results on Wix page
  });
</script>
```

---

## Testing Locally First

Before deploying, test locally:

```bash
cd /Users/ADVAITH1/VSCODESTUFF
pip install -r requirements.txt
gunicorn app:app --bind 0.0.0.0:5000
```

Visit `http://localhost:5000` to verify it works.

---

## Quick Checklist

- ✅ `Procfile` created
- ✅ `requirements.txt` updated with gunicorn
- ✅ `app.py` fixed (PORT environment variable added)
- ✅ Code pushed to GitHub
- ✅ Deployed to Render/Railway/Heroku
- ✅ Integrated into Wix with API calls
